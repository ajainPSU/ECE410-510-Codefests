
import cocotb
from cocotb.triggers import Timer
from cocotb.clock import Clock
from qr_python_file_async import QRCodeRecognizer
from cocotb_testbench import SpiMaster

@cocotb.test()
async def test_spi_rs_correction(dut):
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    dut.cs.value = 1
    dut.clk.value = 0
    dut.sck.value = 0
    dut.mosi.value = 0

    spi = SpiMaster(dut.sck, dut.mosi, dut.miso, dut.cs)

    recognizer = QRCodeRecognizer(trace_mode=True, hardware_mode=True, spi=spi)

    # Use a dummy or mock QR matrix, since image loading is not supported
    dummy_image = [[0 for _ in range(21)] for _ in range(21)]  # Version 1 dummy QR

    payload = await recognizer.recognize(dummy_image)
    dut._log.info(f"Recognized QR Payload: {payload}")
